
package notenoughspam.detector;

import java.util.Arrays;
import java.util.List;

public class SpamDetector {

	private final Double	strongSpamThreshold;
	private final Double	weakSpamThreshold;
	private final String[]	strongSpamWords;
	private final String[]	weakSpamWords;


	public SpamDetector(final Double strongSpamThreshold, final Double weakSpamThreshold, final String[] strongSpamWords, final String[] weakSpamWords) {
		this.strongSpamThreshold = strongSpamThreshold;
		this.weakSpamThreshold = weakSpamThreshold;
		this.strongSpamWords = strongSpamWords;
		this.weakSpamWords = weakSpamWords;
	}

	public boolean stringHasStrongSpam(final String string) {
		Integer countStrongSpam = 0;
		final Integer numberOfWords = string.split("\\s+").length;
		final String[] array = this.strongSpamWords;
		final String[] words = string.toLowerCase().replaceAll("[-+?�!�.^:,]", "").split("\\s+");
		final List<String> spamWords = Arrays.asList(array);
		for (int i = 0; i < words.length; i++) {
			if (i != words.length - 1) {
				if (spamWords.contains(words[i]) || spamWords.contains(words[i] + " " + words[i + 1])) {
					countStrongSpam++;
				}
			} else {
				if (spamWords.contains(words[i])) {
					countStrongSpam++;
				}
			}
		}
		final double ratio = countStrongSpam.doubleValue() / numberOfWords.doubleValue();
		return ratio > this.strongSpamThreshold / 100.0;
	}

	public boolean stringHasWeakSpam(final String string) {
		Integer countWeakSpam = 0;
		final Integer numberOfWords = string.split("\\s+").length;
		final String[] array = this.weakSpamWords;
		final String[] words = string.toLowerCase().replaceAll("[-+?�!�.^:,]", "").split("\\s+");
		final List<String> spamWords = Arrays.asList(array);
		for (int i = 0; i < words.length; i++) {
			if (i != words.length - 1) {
				if (spamWords.contains(words[i]) || spamWords.contains(words[i] + " " + words[i + 1])) {
					countWeakSpam++;
				}
			} else {
				if (spamWords.contains(words[i])) {
					countWeakSpam++;
				}
			}
		}
		final double ratio = countWeakSpam.doubleValue() / numberOfWords.doubleValue();
		return ratio > this.weakSpamThreshold / 100.0;
	}

	public Boolean stringHasNoSpam(final String string) {
		return !(this.stringHasStrongSpam(string) || this.stringHasWeakSpam(string));
	}
}
