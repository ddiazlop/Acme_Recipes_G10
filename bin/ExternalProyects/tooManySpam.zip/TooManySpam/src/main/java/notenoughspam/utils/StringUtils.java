package notenoughspam.utils;


public class StringUtils {
	
	public static Integer countSubstring(final String string, final String substring) {
		return string.split(substring,-1).length-1;
	}
	
	
}
